package objetosBanco;
public class IteradorLista {
	private NodoLista actual;

	public NodoLista getActual() {
		return actual;
	}

	public void setActual(NodoLista actual) {
		this.actual = actual;
	}

	IteradorLista(NodoLista n) {
		this.actual = n;
	}

	boolean estaFuera() {
		if (actual == null)
			return true;
		else
			return false;
	}

	Producto obtener() {
		return this.actual.getElemento();
	}

	void avanzar() {
		if (!estaFuera()) {
			this.actual = this.actual.getSiguiente();
		}
	}
}
package objetosBanco;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Producto prod1 = new Producto(1, "Suavitel", 65);
		// Producto prod2 = new Producto(2, "Jabon Palmolive", 15);
		// Producto prod3 = new Producto(3, "Gel pelo", 20.5);

		Lista lista = new Lista();
		IteradorLista it = new IteradorLista(lista.getCabecera());

		// lista.insertar(prod1, it);
		// lista.insertar(prod2, it);
		// lista.insertar(prod3, it);

		// lista.listarElementos();
		// lista.getTotal();

		// lista.despliegaTicket();

		Scanner input = new Scanner(System.in);

		while (true) {
			System.out.println("|**********Ghetto Walmart**********|");
			System.out.println("|_______________MENU_______________|");
			System.out.println("|(1) Agregar producto al ticket.   |");
			System.out.println("|(2) Actualizar producto en ticket.|");
			System.out.println("|(3) Eliminar producto en ticket.  |");
			System.out.println("|(4) Desplegar ticket.             |");
			System.out.println("|(0) QUIT.                         |");
			System.out.println("|__________________________________|");

			int choice = input.nextInt();

			switch (choice) {

			case 1:

				System.out.println("Ingrese SKU...");
				int skuInput = input.nextInt();
				System.out.println("Ingrese Nombre...");
				String nombreInput = input.next();
				System.out.println("Ingrese Precio...");
				double precioInput = input.nextDouble();

				Producto p = new Producto(skuInput, nombreInput, precioInput);
				lista.insertar(p, it);
				break;

			case 2:
				System.out.println("ACTUALIZAR PRODUCTO EN TICKET. INGRESE SKU...");
				int sku = input.nextInt();
				Producto temp = new Producto(sku);
				IteradorLista it2 = lista.buscar(temp);
				if (it2.estaFuera()) {
					System.out.println("SKU NO EXISTE");
					break;
				}
				// lista.buscar(temp).obtener();
				Producto p1 = it2.obtener();

				System.out.println("INGRESA NUEVO SKU");
				int skuUpdate = input.nextInt();
				p1.setSku(skuUpdate);

				System.out.println("INGRESA NOMBRE NUEVO...");
				String nombreUpdate = input.next();
				p1.setNombre(nombreUpdate);

				System.out.println("INGRESA NUEVO PRECIO...");
				double precioUpdate = input.nextDouble();
				p1.setPrecio(precioUpdate);

				break;

			case 3:
				System.out.println("ELIMINAR PRODUCTO. INGRESE SKU...");
				int borrar = input.nextInt();
				Producto pBorrar = new Producto(borrar);
				lista.eliminar(pBorrar);

			case 4:
				System.out.println("_____________________TICKET____________________");
				lista.despliegaTicket();
				System.out.println("_______________________________________________");
				break;

			case 0:
				System.out.println("Quit.");
				System.exit(0);

			default:
				System.out.println("OPCION INVALIDA");
				break;
			} // switch
		} // while

	}

}

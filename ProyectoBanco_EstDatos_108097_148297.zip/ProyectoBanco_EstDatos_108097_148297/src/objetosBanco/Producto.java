package objetosBanco;

public class Producto {

	
	private int id;
	private String nombre;
	private String apellido;
	private int edad;
	private double saldo;
	
	

	public Producto(int id, String nombre, String apellido, int edad, double saldo) {
		//super();
		this.id = id;
		this.nombre = nombre;
		this.apellido = apellido;
		this.edad = edad;
		this.saldo = saldo;
	}

	public Producto(int sku, String nombre, double precio) {
		//super();
		this.id = sku;
		this.nombre = nombre;
		this.saldo = precio;
	}
	
	public Producto (int sku) {
		this.id = sku;
	}

	public int getSku() {
		return id;
	}

	public void setSku(int sku) {
		this.id = sku;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getPrecio() {
		return saldo;
	}

	public void setPrecio(double precio) {
		this.saldo = precio;
	}

	@Override
	public String toString() {
		return "Producto [sku=" + id + ", nombre=" + nombre + ", precio=" + saldo + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Producto other = (Producto) obj;
		if (id != other.id)
			return false;
		return true;
	}
	
	

}

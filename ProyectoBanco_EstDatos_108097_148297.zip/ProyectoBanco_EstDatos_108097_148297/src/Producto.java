
public class Producto {

	
	private int sku;
	private String nombre;
	private double precio;

	public Producto(int sku, String nombre, double precio) {
		//super();
		this.sku = sku;
		this.nombre = nombre;
		this.precio = precio;
	}
	
	public Producto (int sku) {
		this.sku = sku;
	}

	public int getSku() {
		return sku;
	}

	public void setSku(int sku) {
		this.sku = sku;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	@Override
	public String toString() {
		return "Producto [sku=" + sku + ", nombre=" + nombre + ", precio=" + precio + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + sku;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Producto other = (Producto) obj;
		if (sku != other.sku)
			return false;
		return true;
	}
	
	

}
